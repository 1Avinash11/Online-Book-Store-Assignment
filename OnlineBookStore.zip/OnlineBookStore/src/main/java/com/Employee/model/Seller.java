package com.Employee.model;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
@Data
@Entity
@AllArgsConstructor
@NoArgsConstructor
public class Seller {
	@Id
	private int sellerid;
	private String sellername;
    private List<Integer> booksaled;
}

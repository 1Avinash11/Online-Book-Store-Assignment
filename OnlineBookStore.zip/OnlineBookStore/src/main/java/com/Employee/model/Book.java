package com.Employee.model;

import javax.persistence.Entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Entity
@AllArgsConstructor
@NoArgsConstructor
public class Book {
	
	private int bookno;
	private String bookname;
	private String bookauthor;
	private double bookprice;
  }

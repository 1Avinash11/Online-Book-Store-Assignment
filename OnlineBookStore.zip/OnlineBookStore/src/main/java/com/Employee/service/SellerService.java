package com.Employee.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Employee.model.Seller;
import com.Employee.reposetry.SellerReposetry;

@Service
public class SellerService {
	@Autowired
	SellerReposetry sellerReposetry;
	
	
	
public List<Seller> getSellerss() {
		
		return	sellerReposetry.findAll();	
		}

		public Seller getSeller(int id) {
		  
			return sellerReposetry.findById(id).get();
		}

		public List<Seller> addSellers(List<Seller> seller) {
			return sellerReposetry.saveAll(seller);
		}

		public Seller updateSeller(Seller seller) {
			return sellerReposetry.save(seller);
		}

		public String deleteSeller(int id) {
			sellerReposetry.deleteById(id);
			return "Seller successfuly deleted Id No: "+ id;
		}

		

	}

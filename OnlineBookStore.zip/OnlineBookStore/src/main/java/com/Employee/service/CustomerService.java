package com.Employee.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Employee.model.Book;
import com.Employee.model.Customer;
import com.Employee.reposetry.CustomerReposetry;

@Service
public class CustomerService {
	@Autowired
	CustomerReposetry customerReposetry;

	public List<Customer> getCustomers() {
		
		return	customerReposetry.findAll();	
		}

		public Customer getCustomer(int id) {
		  
			return customerReposetry.findById(id).get();
		}

		public List<Customer> addCustomerss(List<Customer> customer) {
			return customerReposetry.saveAll(customer);
		}

		public Customer updateCustomer(Customer customer) {
			return customerReposetry.save(customer);
		}

		public String deleteCustomer(int id) {
			customerReposetry.deleteById(id);
			return "Customer successfuly deleted Id No: "+ id;
		}

		

	}

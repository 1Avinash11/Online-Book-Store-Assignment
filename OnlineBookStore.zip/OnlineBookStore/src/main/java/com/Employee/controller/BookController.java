package com.Employee.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.Employee.model.Book;
import com.Employee.service.BookService;

@Controller
@RestController
public class BookController {

	@Autowired
	BookService bookService;

	@GetMapping("/books")
	public ResponseEntity<List<Book>> getBooks() {
		List<Book> books = null;
		try {
			books = bookService.getBooks();
			return new ResponseEntity<List<Book>>(books, HttpStatus.OK);
		} catch (Exception e) {
			return new ResponseEntity<List<Book>>(books, HttpStatus.INTERNAL_SERVER_ERROR);
		}

	}

	@GetMapping("/book/{id}")
	public ResponseEntity<Book> getBookById(@PathVariable("id") int id) {
		Book book = null;
		try {
			book = bookService.getBooks(id);
			return new ResponseEntity<Book>(book, HttpStatus.OK);
		} catch (Exception e) {
			return new ResponseEntity<Book>(book, HttpStatus.INTERNAL_SERVER_ERROR);
		}

	}

	@PostMapping("/books")
	public ResponseEntity<List<Book>> addBooks(@RequestBody List<Book> books) {
		try {
			books = bookService.addBooks(books);
			return new ResponseEntity<List<Book>>(books, HttpStatus.OK);
		} catch (Exception e) {
			return new ResponseEntity<List<Book>>(books, HttpStatus.INTERNAL_SERVER_ERROR);
		}

	}

	@PostMapping("/books")
	public ResponseEntity<Book> updateBookById(@RequestBody Book book) {
		try {
			Book exist = bookService.getBooks(book.getBookno());
			if (exist != null)
				book = bookService.updateBook(book);
			return new ResponseEntity<Book>(book, HttpStatus.OK);
		} catch (Exception e) {
			return new ResponseEntity<Book>(book, HttpStatus.INTERNAL_SERVER_ERROR);
		}

	}

	@DeleteMapping("/book/{id}")
	public ResponseEntity<String> updateBookById(@PathVariable("id") int id) {
		String message = "";
		try {
			message = bookService.deleteBook(id);

			return new ResponseEntity<String>(message, HttpStatus.OK);
		} catch (Exception e) {
			return new ResponseEntity<String>(message, HttpStatus.INTERNAL_SERVER_ERROR);
		}

	}

}

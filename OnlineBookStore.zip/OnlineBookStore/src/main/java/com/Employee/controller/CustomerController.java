package com.Employee.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.Employee.model.Customer;
import com.Employee.service.CustomerService;
@Controller
@RestController
public class CustomerController {
	
 @Autowired
 CustomerService customerService;
	@GetMapping("/customers")
	public ResponseEntity<List<Customer>> getCustomers() {
		List<Customer> customer = null;
		try {
			customer = customerService.getCustomers();
			return new ResponseEntity<List<Customer>>(customer, HttpStatus.OK);
		} catch (Exception e) {
			return new ResponseEntity<List<Customer>>(customer, HttpStatus.INTERNAL_SERVER_ERROR);
		}

	}
	
	@GetMapping("/customer/{id}")
	public ResponseEntity<Customer> getCustomerById(@PathVariable("id") int id) {
		Customer customer = null;
		try {
			customer = customerService.getCustomer(id);
			return new ResponseEntity<Customer>(customer, HttpStatus.OK);
		} catch (Exception e) {
			return new ResponseEntity<Customer>(customer, HttpStatus.INTERNAL_SERVER_ERROR);
		}

	}

	@PostMapping("/customers")
	public ResponseEntity<List<Customer>> addCustomers(@RequestBody List<Customer> customers) {
		try {
			customers = customerService.addCustomerss(customers);
			return new ResponseEntity<List<Customer>>(customers, HttpStatus.OK);
		} catch (Exception e) {
			return new ResponseEntity<List<Customer>>(customers, HttpStatus.INTERNAL_SERVER_ERROR);
		}

	}

	@PutMapping("/customers")
	public ResponseEntity<Customer> updateCustomerById(@RequestBody Customer customer) {
		try {
			Customer exist = customerService.getCustomer(customer.getCustumerid());
			if (exist != null)
				customer = customerService.updateCustomer(customer);
			return new ResponseEntity<Customer>(customer, HttpStatus.OK);
		} catch (Exception e) {
			return new ResponseEntity<Customer>(customer, HttpStatus.INTERNAL_SERVER_ERROR);
		}

	}

	@DeleteMapping("/customer/{id}")
	public ResponseEntity<String> updateBookById(@PathVariable("id") int id) {
		String message = "";
		try {
			message = customerService.deleteCustomer(id);

			return new ResponseEntity<String>(message, HttpStatus.OK);
		} catch (Exception e) {
			return new ResponseEntity<String>(message, HttpStatus.INTERNAL_SERVER_ERROR);
		}

	}

}




package com.Employee.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.Employee.model.Customer;
import com.Employee.model.Seller;
import com.Employee.service.SellerService;

@Controller
@RestController
public class SellerController {

	@Autowired
	SellerService sellerService;
	
	@GetMapping("/sellers")
	public ResponseEntity<List<Seller>> getCustomers() {
		List<Seller> seller = null;
		try {
			seller = sellerService.getSellerss();
			return new ResponseEntity<List<Seller>>(seller, HttpStatus.OK);
		} catch (Exception e) {
			return new ResponseEntity<List<Seller>>(seller, HttpStatus.INTERNAL_SERVER_ERROR);
		}

	}
	
	@GetMapping("/seller/{id}")
	public ResponseEntity<Seller> getSellerById(@PathVariable("id") int id) {
		Seller seller = null;
		try {
			seller = sellerService.getSeller(id);
			return new ResponseEntity<Seller>(seller, HttpStatus.OK);
		} catch (Exception e) {
			return new ResponseEntity<Seller>(seller, HttpStatus.INTERNAL_SERVER_ERROR);
		}

	}

	@PostMapping("/sellers")
	public ResponseEntity<List<Seller>> addSellers(@RequestBody List<Seller> sellers) {
		try {
			sellers = sellerService.addSellers(sellers);
			return new ResponseEntity<List<Seller>>(sellers, HttpStatus.OK);
		} catch (Exception e) {
			return new ResponseEntity<List<Seller>>(sellers, HttpStatus.INTERNAL_SERVER_ERROR);
		}

	}

	@PutMapping("/sellers")
	public ResponseEntity<Seller> updateSellerById(@RequestBody Seller seller) {
		try {
			Seller exist = sellerService.getSeller(seller.getSellerid());
			if (exist != null)
				seller = sellerService.updateSeller(seller);
			return new ResponseEntity<Seller>(seller, HttpStatus.OK);
		} catch (Exception e) {
			return new ResponseEntity<Seller>(seller, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		

	}

	@DeleteMapping("/sellers/{id}")
	public ResponseEntity<String> updateBookById(@PathVariable("id") int id) {
		String message = "";
		try {
			message = sellerService.deleteSeller(id);

			return new ResponseEntity<String>(message, HttpStatus.OK);
		} catch (Exception e) {
			return new ResponseEntity<String>(message, HttpStatus.INTERNAL_SERVER_ERROR);
		}

	}

}
	
	


